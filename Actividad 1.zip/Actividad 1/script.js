function reservarBalcon(balcon, numeroAsientos) {
    if(numeroAsientos > balcon.asientos) {
        alert("No hay disponible tantos asientos libres esta sección.");
    }
    else {
        balcon.asientosLibres -= numeroAsientos;
        var i = 0;
        do {
            if(balcon.asientos[i]) {
                balcon.asientos[i] = false;
                numeroAsientos--;
            }
            i++;
        }while((numeroAsientos > 0) && (i < balcon.asientos.length));
        alert("Reserva realizada con éxito.");
    }
    return balcon;
}

function reservarPatioButacas(patioButacas, numeroAsientos) {
    if(numeroAsientos > patioButacas.asientos) {
        alert("No hay disponible tantos asientos libres esta sección.");
    }
    else {
        patioButacas.asientosLibres -= numeroAsientos;
        var i = 0;
        do {
            if(patioButacas.asientos[i]) {
                patioButacas.asientos[i] = false;
                numeroAsientos--;
            }
            i++;
        }while((numeroAsientos > 0) && (i < patioButacas.asientos.length));
        alert("Reserva realizada con éxito.");
    }
    return patioButacas;
}

function inicializar(patioButacas, balcon) {
    patioButacas.asientosLibres = 0;
    balcon.asientosLibres = 0;
    for(var i = 0; i < balcon.asientos.length; i++)
        balcon.asientos[i] = true;
    for(var i = 0; i < patioButacas.asientos.length; i++)
        patioButacas.asientos[i] = true;
}

var patioButacas = {};
patioButacas.asientosLibres = 0;
patioButacas.asientos = new Array(9);
var balcon = {};
balcon.asientosLibres = 0;
balcon.asientos = new Array(6);
inicializar(patioButacas, balcon);
var salir = false;
while(!salir) {
    var correcto = false;
    while(!correcto) {
        var opcion = parseInt(prompt("MENÚ:\n[1]Reservar en balcón.\n[2]Reservar en patio de butacas.\n[0]Salir.\nElija una opción:"));
        if(isNaN(opcion))
            alert("La opción introducida no es numérica");
        else
            correcto = true;
    }
    switch(opcion) {
        case 1: 
            var correcto = false;
            while(!correcto) {
                var numeroAsientos = parseInt(prompt("MENÚ:\n[1]Reservar en balcón.\n[2]Reservar en patio de butacas.\n[0]Salir.\nElija una opción:"));
                if(isNaN(opcion))
                    alert("La opción introducida no es numérica");
                else
                    correcto = true;
            }
            balcon = reservarBalcon(balcon, numeroAsientos);
            break;
        case 2: 
            var correcto = false;
            while(!correcto) {
                var numeroAsientos = parseInt(prompt("MENÚ:\n[1]Reservar en balcón.\n[2]Reservar en patio de butacas.\n[0]Salir.\nElija una opción:"));
                if(isNaN(opcion))
                    alert("La opción introducida no es numérica");
                else
                    correcto = true;
            }
            patioButacas = reservarPatioButacas(patioButacas, numeroAsientos);
            break;
        case 0: salir = true;
            break;
        default: alert("No existe opción con ese valor.");
    }
}